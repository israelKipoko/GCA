<div class="status_wrapper">
    <h1 class="capitalize text-center w-fit" id="{{($value == "pending")? "pending": "submitted"}}">{{$value}}</h1>
</div>