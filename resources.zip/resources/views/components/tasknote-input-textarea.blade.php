<dialog id="task_note_input_textArea">
<div class="relative max-w-sm">
    <textarea name="note" id="note" cols="30" rows="10" placeholder={{__("Entrez une note la tâche...")}}>
    </textarea>
</dialog>