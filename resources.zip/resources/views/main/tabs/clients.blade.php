@extends('layout')

@section('content')
<section>
    <div id="home_wrapper">
        <section id="main" class="px-1">
           
            <div class="">
                <div id="clientsTable"></div>
            </div>
        </section>
    </div>
</section>
@endsection