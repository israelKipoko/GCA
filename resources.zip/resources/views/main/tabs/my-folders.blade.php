@extends('layout')

@section('content')
    <section class="container mx-auto">
        <div id="home_wrapper">
            <section id="" class="">
                <div class="">
                    <div id="table"></div>
               </div>
            </section>
        </div>
    </section>
@endsection