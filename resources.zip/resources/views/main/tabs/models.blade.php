@extends('layout')

@section('content')
    <section class="container mx-auto">
        <div id="home_wrapper">
            <section id="main" class=" grid grid-cols-2">
                
            </section>
        </div>
    </section>
@endsection